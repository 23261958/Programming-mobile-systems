//File injectable service
import { Injectable } from '@angular/core';
import { File } from '@ionic-native/file/ngx';

export interface Pet {
	pName: string;
	pNumber: number;
    pSpecies: string;
    psex :string;
    pAge : string; 
}


@Injectable()

export class FileData{
    fileName: string = "pets.json";
    pets: Pet[]=[]; 
    pList : string = "";
    constructor(public file : File){}
    
    addPet(p: Pet){
		this.pets.push(p);
		this.writeToFile();
	}
    delPet(p:Pet){
		this.removeFile();
    }
    removeFile(){
        let fileText: string = JSON.stringify(this.pets); 
        		this.file.removeFile(this.file.dataDirectory, this.fileName)
			.then(  // this returns a promise
				 (fw)=> {console.log("Removing the file was successful.");}, // success
				 (err)=> {console.log("Error in removing the file!");} //failure
			);
	}
        
    writeToFile(){
		let fileText: string = JSON.stringify(this.pets); 
        		this.file.writeFile(this.file.dataDirectory, this.fileName, fileText, {replace: true})
			.then(  // this returns a promise
				 (fw)=> {console.log("Writing the file was successful.");}, // success
				 (err)=> {console.log("Error in writing the file!");} //failure
			);
	}
    	readFromFile() : string {
		this.file.readAsText(this.file.dataDirectory,this.fileName)
		.then(
			(txt)=> { this.pList = txt;}, //success
			(err)=> { console.log("Error in reading the file!");} //failure
		);
		return this.pList;
	}
}
