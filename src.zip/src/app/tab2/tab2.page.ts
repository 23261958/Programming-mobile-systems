import { Component } from '@angular/core';
import { FileData } from '../../app/file.service';
import { Pet } from '../../app/file.service';
import { AlertController } from '@ionic/angular';



@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page {
 petName : string;
 petNumber : number;
 species: string;
 sex :string;
 Age : string;
 promptAlertInput : string = "";



  	constructor(public pData: FileData
    ,public alertCtrl: AlertController) {}
	
	doAdd(){
		let p : Pet = { pName: this.petName ,pNumber: this.petNumber , pSpecies : this.species, psex:this.sex, pAge : this.Age }
		this.pData.addPet(p);
        
        
    }
    	async presentPromptAlert(){
		const promptAlert = await this.alertCtrl.create({
				header: 'Read instruction',
				message: "<p> You can use add Pet page to add new pet,list pet page to show the list of the pages and edit pet page to edit the pet. </p>  ",

                   buttons:[{
					text: 'OK',
					handler: data => {}
				}]
		});
		await promptAlert.present();
	}

    
		
	}
		



