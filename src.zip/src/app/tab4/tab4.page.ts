import { Component } from '@angular/core';
import { FileData } from '../../app/file.service';
import { Pet } from '../../app/file.service';
import { AlertController } from '@ionic/angular';


@Component({
  selector: 'app-tab4',
  templateUrl: 'tab4.page.html',
  styleUrls: ['tab4.page.scss']
})
export class Tab4Page {
    promptAlertInput : string = "";
   petName : string;
 petNumber : number;
 species: string;
 sex :string;
 Age : string; 
     data :Pet[];//temporary arroay

 position : number = -1;
	constructor(public alertCtrl: AlertController , public pData: FileData) {}
    	dodel(){
		this.data.splice(this.position,1);
		if (this.position == this.data.length) {
			this.position--; 
		}
		if ( this.data.length == 0) { 
			 this.petName = "";
            this.species = "";
            this.sex = "";
            this.Age = "";
			} else { //check if there are book in the array
            this.petName = this.data[this.position].pName;
			this.petNumber = this.data[this.position].pNumber;
            this.species = this.data[this.position].pSpecies;
			this.sex = this.data[this.position].psex;
            this.Age = this.data[this.position].pAge;
			}
		
	}
  	async presentPromptAlert(){
		  const promptAlert = await this.alertCtrl.create({
				header: 'Delete ',
				message: "Are you sure want to delete",
				buttons:[{
					text: 'Cancel',
                    role:  'cancel',
                handler: () => {
                          console.log('Cancel clicked');
                        }
				},
                {
					text: 'Delete',
                 handler: () => {
                          console.log('Delete clicked');
                          this.dodel(); 
				}
                }
                ]
		});
		await promptAlert.present();
	
     }
    async presentPromptAlertt(){
		const promptAlert = await this.alertCtrl.create({
				header: 'Read instruction',
				message: "<p> You can use add Pet page to add new pet,list pet page to show the list of the pages and edit pet page to edit the pet. </p>  ",

                   buttons:[{
					text: 'OK',
					handler: data => {}
				}]
		});
		await promptAlert.present();
	}

    
	}
  

