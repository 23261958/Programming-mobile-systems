import { Component } from '@angular/core';
import { FileData } from '../../app/file.service';
import { Pet } from '../../app/file.service';
import { AlertController } from '@ionic/angular';


@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss']
})
export class Tab3Page {
    pList : string = "";
     promptAlertInput : string = "";

     constructor(public pData: FileData, public alertCtrl: AlertController) {}
     showList(){
		this.pList = this.pData.readFromFile();
  }
      	async presentPromptAlert(){
		const promptAlert = await this.alertCtrl.create({
				header: 'Read instruction',
				message: "<p> You can use add Pet page to add new pet,list pet page to show the list of the pages and edit pet page to edit the pet. </p>  ",

                   buttons:[{
					text: 'OK',
					handler: data => {}
				}]
		});
		await promptAlert.present();
	}

}

